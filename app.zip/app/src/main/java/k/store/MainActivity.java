package k.store;


import android.content.Intent;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import SlidingTabs.SlidingTabLayout;
import SlidingTabs.SlidingTabAdapter;
import k.store.R;
import k.store.kiks.Popular;


public class MainActivity extends ActionBarActivity {

    ActionBarDrawerToggle mDrawerToggle;
    DrawerLayout mDrawerLayout;
    SlidingTabLayout mSlidingTabLayout;
    ViewPager mViewPager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.initLayout();
        this.bindTabEvents();
        this.bindNavDrawerEvents();

        this.addContent();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        // when a nav button is clicked
        if (mDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        int id = item.getItemId();
//left button in settings menu to close activity (need to fix it from exiting activity, exit whole app)
        if (id == R.id.action_exit) {
            System.exit(0);
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        mDrawerToggle.syncState();
    }

    @Override
    public void onBackPressed() {
        // back button closes drawer
        if (mDrawerLayout.isDrawerOpen(Gravity.START | Gravity.LEFT)) {
            mDrawerLayout.closeDrawers();
            return;
        }
        super.onBackPressed();
    }

    public void initLayout() {
        // toolbar DO NOT TOUCHY
        Toolbar mToolbar = (Toolbar) findViewById(R.id.toolbar_actionbar);
        setSupportActionBar(mToolbar);


        // nav drawer DO NOT TOUCHY
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        mDrawerLayout.setStatusBarBackgroundColor(getResources().getColor(R.color.colorMainDark));

        // bind navd drawer to nav toggle DO NOT TOUCHY
        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, mToolbar, R.string.app_name, R.string.app_name);
        mDrawerLayout.setDrawerListener(mDrawerToggle);

        // view pager for the tabs, can click or scroll like normla one
        mViewPager = (ViewPager) findViewById(R.id.view_pager);
        mViewPager.setOffscreenPageLimit(5);
        mViewPager.setAdapter(new SlidingTabAdapter());

        // bind sliding tabs to view finder
        mSlidingTabLayout = (SlidingTabLayout) findViewById(R.id.sliding_tabs);

        // styling for tabs, you may touchy
        mSlidingTabLayout.setCustomTabView(R.layout.toolbar_tab, R.id.toolbar_tab_txtCaption);
        mSlidingTabLayout.setSelectedIndicatorColors(getResources().getColor(R.color.tab_indicator_color));

        mSlidingTabLayout.setDistributeEvenly(true); // tabs are equal size no touch
        mSlidingTabLayout.setViewPager(mViewPager);

    }

    public void bindTabEvents() {
        // tab events
        if (mSlidingTabLayout != null) {
            mSlidingTabLayout.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int position, float positionOffset,
                                           int positionOffsetPixels) {
                }
                @Override
                public void onPageSelected(int position) {
                }
                @Override
                public void onPageScrollStateChanged(int state) {
                }
            });
        }
    }

    public void bindNavDrawerEvents() {
        // these are for the navigation buttons, copy paste the nav drawer button in menu_main and make new id. rest is self explanatory coi
        LinearLayout home = (LinearLayout) findViewById(R.id.home);
        home.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity.this,MainActivity.class);
                startActivity(i);
            }
        });

        LinearLayout popular = (LinearLayout) findViewById(R.id.popular);
        popular.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity.this,Popular.class);
                startActivity(i);
            }
        });

    }

    public void addContent(){

        // add tabs like this, just copy/paste the tab_mods or retheme or whatever and put layout name
        addTab(R.layout.tabcontent_1,"Home");
        addTab(R.layout.tabcontent_2, "Featured");
        addTab(R.layout.tabcontent_3, "Developers");

    }

    public void addTab(int layout,String tabTitle)
    {
        this.addTab(layout,tabTitle,-1);
    }
    public void addTab(int layout,String tabTitle,int position)
    {
        SlidingTabAdapter mTabs = (SlidingTabAdapter)mViewPager.getAdapter();
        mTabs.addView(getLayoutInflater().inflate(layout,null),tabTitle,position);
        mTabs.notifyDataSetChanged();
        mSlidingTabLayout.populateTabStrip();
    }

    public void removeTab()
    {
        this.removeTab(-1);
    }
    public void removeTab(int position)
    {
        SlidingTabAdapter mTabs = (SlidingTabAdapter)mViewPager.getAdapter();
        mTabs.removeView(position);
        mTabs.notifyDataSetChanged();
        mSlidingTabLayout.populateTabStrip();
    }
}
