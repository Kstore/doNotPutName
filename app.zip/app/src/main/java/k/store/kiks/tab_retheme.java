package k.store.kiks;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import k.store.R;

public class tab_retheme extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tab_retheme);
    }
}
