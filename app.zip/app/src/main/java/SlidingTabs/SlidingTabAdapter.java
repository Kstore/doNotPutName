package SlidingTabs;

import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by subaroot on 12/01/2016
 */
public class SlidingTabAdapter extends PagerAdapter {

    SparseArray<View> views = new SparseArray<View>();
    SparseArray<String> pageTitles = new SparseArray<String>();


    @Override
    public int getCount() {
        return views.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object o) {
        return o == view;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return pageTitles.get(position);
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        View v = views.get(position);
        container.addView(v);
        return v;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
        views.remove(position);
    }

    public int addView(View v, String title) {
        return this.addView(v, title, -1);
    }

    public int addView(View v, String title, int position) {
        if (position == -1) {
            position = views.size();
        }
        views.put(position, v);
        pageTitles.put(position, title);
        return position;
    }

    public int removeView() {
        return this.removeView(-1);
    }

    public int removeView(int position) {
        if (position == -1) {
            position = views.size() - 1;
        }
        if (position > 0) {
            views.remove(position);
            pageTitles.remove(position);
        }
        return position;
    }

}
